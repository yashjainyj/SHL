import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WebsiteComponent } from './website/website.component';

import {HttpClientModule} from '@angular/common/http';


import {InputTextModule} from 'primeng/inputtext';
import {TabViewModule} from 'primeng/tabview';
import {InputTextareaModule} from 'primeng/inputtextarea';
// import {ChartModule} from 'primeng/chart';
import {ToastModule} from 'primeng/toast';
import {DialogModule} from 'primeng/dialog';
import {SidebarModule} from 'primeng/sidebar';
import {TableModule} from 'primeng/table';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {CalendarModule} from 'primeng/calendar';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import { FormsModule } from '@angular/forms';
import {TimelineModule} from 'primeng/timeline';
import {CardModule} from 'primeng/card';import { GalleriaModule } from 'primeng/galleria';
import {ColorPickerModule} from 'primeng/colorpicker';
@NgModule({
  declarations: [	
    AppComponent,
      WebsiteComponent
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    GalleriaModule,
    TimelineModule,
    CardModule,
    ToastModule,
    FormsModule,
    CalendarModule,
    HttpClientModule,
    DialogModule,
    TableModule,
    ConfirmDialogModule,
    OverlayPanelModule,
    InputTextModule,
    TabViewModule,InputTextareaModule,ColorPickerModule,
    // ChartModule,/
    SidebarModule
  ],
  providers: [],
  schemas:[CUSTOM_ELEMENTS_SCHEMA],

  bootstrap: [AppComponent]
})
export class AppModule { }
