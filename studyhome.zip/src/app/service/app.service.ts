import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AppService {
url =''
constructor(private http:HttpClient) { 
  this.url = environment.url
}

getFacilities(){
  return this.http.get(this.url+'facilities')
}

getAbout(){
  return this.http.get(this.url+'about')
}


}
