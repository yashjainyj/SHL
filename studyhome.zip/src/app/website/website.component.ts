import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AppService } from '../service/app.service';

@Component({
  selector: 'app-website',
  templateUrl: './website.component.html',
  styleUrls: ['./website.component.css']
})
export class WebsiteComponent implements OnInit {
  Address='A.B Road Near Aakar IAS Coaching Classes Bhola Ram Gate , Bhavarkua,Indore(M.P.) 452001'
  // ContactUSDetails:ContactUsDetail=new ContactUsDetail();
  facilitiesList:any[]=[]  
  aboutUs: any[];
  ImagesUrl:any=[]
  // map:Map
  TC=[]
  title=''
  hidemain=false
  hideAboutus=false
  overlays: any[];
  constructor(private app:AppService) { }

  ngOnInit() {
    this.app.getFacilities().subscribe(res=>{
      console.log(res);
      
      this.facilitiesList = res['Facilities']
    })
    this.app.getAbout().subscribe(res=>{
      console.log(res);
      
      this.aboutUs = res['AboutUs']
    })
  }
  contactUsSubmit(form:NgForm){

  }
  legalClick(purpose){

  }
}
